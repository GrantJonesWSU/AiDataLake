#----------------------------------------------------
# Import Library/Function Definitions
#----------------------------------------------------
#Imports
from django.shortcuts import render
from django.http import HttpRequest
from rest_framework.request import Request

#Functions
def find_between( s, first, last ):
    try:
        start = s.index( first ) + len( first )
        end = s.index( last, start )
        return s[start:end]
    except ValueError:
        return ""
#----------------------------------------------------

#----------------------------------------------------
# Variable Declarations
#----------------------------------------------------
tableList=[]
tableCountComp=[]
tableColumn=[]
arrTemp=[]
#----------------------------------------------------

#---------------------------------------------------
#Enter POST request from prompt
#---------------------------------------------------
def file_upload(request):
	if request.method == "POST":
		#Contain db file in local memory
		#Also manipulate as string for file type checking
		readDB=request.FILES
		readDBFormat=str(readDB)
		
		print(readDB)
		print("-----------------")
		#File Type Checking
		if(readDBFormat.find(".sql")==-1):

			#File Type Fail

			print("Improper file type uploaded, being ignored by functionality")
			return render(request,"home.html")

		else:

			#File Type Success

			print("Successfully Obtained DB File")
			return render(request,"home.html")






