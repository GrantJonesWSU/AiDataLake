from django.http import request
from django.shortcuts import render
import re
from django.utils.timezone import datetime
from .models import *
from .forms import questionForm
 

# Create your views here.
def home_view(request):
	recentData = UserLogin.objects.query("requesttext", "metageneration")
	return render(request,"home.html")

def instruction_view(request):
	return render(request,"instructions.html")

