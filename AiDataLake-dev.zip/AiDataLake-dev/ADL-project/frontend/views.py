from django.http import request
from django.shortcuts import render
import re
from django.utils.timezone import datetime

 

# Create your views here.
def home_view(request):
	return render(request,"home.html")
