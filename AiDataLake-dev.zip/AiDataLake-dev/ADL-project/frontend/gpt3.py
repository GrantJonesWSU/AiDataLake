#----------------------------------------------------
# Import Library/Function Definitions
#----------------------------------------------------
#Imports
from django.shortcuts import render
from django.http import HttpRequest
from rest_framework.request import Request
#----------------------------------------------------

#Handles GPT3 Operation
def gpt_function(request):
	if request.method == "POST":
		#Create Dict of Request
		readDB=request.POST

		#Search For ID Of Request
		for key in readDB:
			if (key=="search"):
				queryString=readDB[key]
	
	

	return render(request,"home.html")