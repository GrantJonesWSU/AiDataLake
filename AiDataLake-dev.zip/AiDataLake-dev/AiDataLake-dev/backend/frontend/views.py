from django.http import request
from django.shortcuts import render

# Create your views here.
def home_view(request):
	#return render(request,"home.html")
	return render(request,"test.html")