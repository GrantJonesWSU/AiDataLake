-- SQLite
INSERT INTO UserDatabase (id, dbName, schemaString, dateTimeCreated, userId_id)
VALUES (1, 'TestDatabase', 'Instructions: The currently selected database has table customers with columns id, name, table sales with columns id, customer_id, description, price.', datetime('now'), 1);