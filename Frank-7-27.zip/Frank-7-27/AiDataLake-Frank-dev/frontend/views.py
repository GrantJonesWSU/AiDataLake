import re
from django.http import request
from django.shortcuts import render
from django.utils.timezone import datetime
from frontend.models import GptInputOutput
from frontend.models import GptIOManager
from frontend.models import UserDatabase
from frontend.models import UserDatabaseManager
from frontend.models import UserDatabaseEntity
from frontend.models import UserDatabaseEntityManager
from frontend.gpt3 import GetGptResponse
from frontend.gpt3 import TrainGptInputGeneric
from frontend.gpt3 import TrainGptInputSql
from frontend.gpt3 import TrainGptCorpus
from frontend.models import UserLogin

#Query for active user

activeUser=UserLogin.objects.filter(loginStatus=1)
if(len(activeUser)!=0):
	activeUsername=str(activeUser[1].username)
	activeUserID=int(activeUser[1].id)
else:
	activeUsername="Guest User"
	activeUserID=-1


#Query for drop down population
#Disallows access unless signed in
#if(activeUserID==-1):
	
#else:
	#userDatabase=UserDatabaseEntity.objects.filter(userId=activeUserID)
	
	#if(len(userDatabase)==0):
		#dropdownOption="#NONE"
	#else:
		#dropdownOption=userDatabase

# Create your views here
def home_view(request):
	

	return render(request,"home.html",{"logged_in" : activeUsername})

def instruction_view(request):
	return render(request,"instructions.html")

# Handles User Login
def user_login(request):
	# needs to render the login page and then upon login
	# redirect to the home page
	return render(request, "home.html",{"logged_in" : activeUsername})

# Handles DB Schema File
def file_upload(request):
	return render(request,"home.html",{"logged_in" : activeUsername})

# Handles User History Query
def user_history(request):
	userHistory = GptInputOutput.objects.all()
	# fetch the history and then send to page render

	return render(request,"output.html", {"user_history_list" : userHistory})

# Handles Recent Meta Query
def recent_meta(request):
	recentMeta = "no recent meta to show or encountered error"
	return render(request,"output.html", {"recent_meta_output" : recentMeta})

  

def gpt_view(request):
	gptOutput = "none, may have been an error or bug"

	if request.method == "POST":
		# Create Dict of Request
		readRequest=request.POST

		# Store Query String
		queryString=readRequest["genericGptInput"]

		# Need to change the hardcoded 1 to a stored db name for the user to select
		trainedInput = TrainGptInputGeneric(queryString, 1)
		gptOutput = "OUTPUT: " + GetGptResponse(trainedInput)

		gptObject = GptInputOutput.objects.createGptIO(queryString, trainedInput, gptOutput, datetime.now())
		gptObject.save()

	return render(request,"output.html", {"gpt_output" : gptOutput})
	
def gpt_sql_view(request):
	gptOutput = "none, may have been an error or bug"

	if request.method == "POST":
		# Create Dict of Request
		readRequest=request.POST

		# Store Query String
		queryString=readRequest["sqlGptInput"]

		# Need to change the hardcoded 1 to a stored db name for the user to select
		trainedInput = TrainGptInputGeneric(queryString, 1)
		gptOutput = "OUTPUT: SELECT " + str(GetGptResponse(trainedInput))

		# Save to Database
		gptObject = GptInputOutput.objects.createGptIO(queryString, trainedInput, gptOutput, datetime.now())
		gptObject.save()
	
	return render(request,"output.html", {"gpt_output" : gptOutput})
